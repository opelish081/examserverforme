package sit.int204.classicmodelservice.controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import sit.int204.classicmodelservice.dtos.SimpleCustomerDTO;
import sit.int204.classicmodelservice.entities.Customer;
import sit.int204.classicmodelservice.repositories.CustomerRepository;
import sit.int204.classicmodelservice.services.CustomerService;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {
    @Autowired
    private CustomerService service;

    @Autowired
    private ModelMapper modelMapper;

//    @GetMapping("")
//    public List<Customer> getCustomer() {
//        return customerRepository.findAll();
//    }

    @GetMapping("/{customerId}")
    public SimpleCustomerDTO getSimpleCustomerById(@PathVariable Integer customerId){
        return modelMapper.map(service.getCustomerById(customerId), SimpleCustomerDTO.class);
    }

    @GetMapping("")
    public List<SimpleCustomerDTO> getCustomers() {
        List<Customer> customersList = service.getCustomers();
//        List<SimpleCustomerDTO> customerDTOList = new ArrayList(customerList.size());
//        for (Customer c : customerList){
//            SimpleCustomerDTO sc = modelMapper.map(c ,SimpleCustomerDTO.class);
//            customerDTOList.add(sc);
//        }
        List<SimpleCustomerDTO> customerDTOList = customersList.stream().map(c -> modelMapper.map(c, SimpleCustomerDTO.class)).collect(Collectors.toList());
        return  customerDTOList;
    }
}
