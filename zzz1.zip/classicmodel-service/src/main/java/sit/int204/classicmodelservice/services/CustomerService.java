package sit.int204.classicmodelservice.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.server.ResponseStatusException;
import sit.int204.classicmodelservice.dtos.LoginDTO;
import sit.int204.classicmodelservice.entities.Customer;
import sit.int204.classicmodelservice.repositories.CustomerRepository;

import java.util.List;

@Service
public class CustomerService {
    @Autowired
    private CustomerRepository repository;

    public Customer getCustomerById(Integer customerId) {
        return repository.findById(customerId).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Customer id" + customerId + "Does Not Exist!"));
    }

    public List<Customer> getCustomers() {
        return repository.findAll();
    }

    //    public Customer login(LoginDTO loginDTO) {
//        Customer customer = repository.findCustomerByIdAndCustomerName(loginDTO.getCustomerNumber(), loginDTO.getCustomerName()).orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Login Fail"));
//        return customer;
//    }
    public Customer login(String customerName, String password) {
        Customer customer = repository.findCustomerByCustomerNameAndPassword(customerName, password).orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Login Fail"));
        return customer;
    }
}
