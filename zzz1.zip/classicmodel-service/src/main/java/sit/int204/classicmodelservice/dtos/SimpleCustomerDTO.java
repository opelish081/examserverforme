package sit.int204.classicmodelservice.dtos;

import lombok.Getter;
import lombok.Setter;
import net.minidev.json.annotate.JsonIgnore;

@Getter
@Setter
public class SimpleCustomerDTO {
    private String customerName;
    private String phone;
    private String city;
    private String country;
    private String salesPerson;

    private String salesRepEmployeeFirstName;
    private String salesRepEmployeeLastName;

    @JsonIgnore
    private SimpleEmployeeDTO sales;
    public String getSalesPerson(){
        return sales == null ? "-":sales.getName();
    }
}
