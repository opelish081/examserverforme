package sit.int204.classicmodelservice.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
import sit.int204.classicmodelservice.entities.Customer;
import sit.int204.classicmodelservice.repositories.CustomerRepository;

public class LoginService {

//    private CustomerRepository repository;
//    public Customer login(String customerName, String password) {
//        Customer customer = repository.findCustomerByCustomerNameAndPassword(customerName, password).orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Login Fail"));
//        return customer;
//    }
}
