package sit.int204.classicmodelservice.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import sit.int204.classicmodelservice.entities.Customer;

import java.util.List;
import java.util.Optional;

public interface CustomerRepository extends JpaRepository<Customer, Integer> {
    public Optional<Customer> findCustomerByCustomerNameAndPassword( String customerName, String password);
//    public List<Customer> findCustomerByCustomerNameAndPassword(String customerName, String password);
}
