package sit.int204.classicmodelservice.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import sit.int204.classicmodelservice.entities.Product;

import java.util.List;

public interface ProductRepository extends JpaRepository<Product, String> {
//    @Query("select p from Product p where p.price >= ?1 and p.price <= ?2")
//    List<Product> findProductsByPriceRange(Double price1, Double price2);

    List<Product> findAllByPriceBetweenOrderByPriceDesc(Double low, Double high);
    List<Product> findAllByProductLineContainingOrderByProductCodeAsc(String productLine);
}