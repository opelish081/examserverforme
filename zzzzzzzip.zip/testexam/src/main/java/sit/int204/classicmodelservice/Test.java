package sit.int204.classicmodelservice;

import org.springframework.data.domain.Sort;

import java.util.ArrayList;
import java.util.List;

public class Test {
    public static void main(String[] args) {
        List<Sort.Order> orders = new ArrayList<>();

        Sort.Order order1 = new Sort.Order(Sort.Direction.DESC, "employeeNumber");
        Sort.Order order2 = new Sort.Order(Sort.Direction.DESC, "jobTitle");
        orders.add(order1);
        orders.add(order2);

        System.out.println(orders);
    }
}
