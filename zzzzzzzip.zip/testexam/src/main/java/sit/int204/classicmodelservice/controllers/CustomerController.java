package sit.int204.classicmodelservice.controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import sit.int204.classicmodelservice.dtos.CustomerDto;
import sit.int204.classicmodelservice.entities.Customer;
import sit.int204.classicmodelservice.services.CustomerService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {
    @Autowired
    private CustomerService service;
    @Autowired
    private ModelMapper modelMapper;
    @GetMapping("/{customerId}")
    public CustomerDto getCustomerById(@PathVariable Integer customerId){
    return modelMapper.map(service.getCustomerById(customerId), CustomerDto.class);
    }

    @GetMapping("")
    public List<CustomerDto> getCustomers() {
        List<Customer> customersList = service.getCustomers();
//        List<SimpleCustomerDTO> customerDTOList = new ArrayList(customerList.size());
//        for (Customer c : customerList){
//            SimpleCustomerDTO sc = modelMapper.map(c ,SimpleCustomerDTO.class);
//            customerDTOList.add(sc);
//        }
        List<CustomerDto> customerDTOList = customersList.stream().map(c -> modelMapper.map(c, CustomerDto.class)).collect(Collectors.toList());
        return  customerDTOList;
    }
}
