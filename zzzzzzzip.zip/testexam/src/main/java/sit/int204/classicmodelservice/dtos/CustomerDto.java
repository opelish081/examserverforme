package sit.int204.classicmodelservice.dtos;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CustomerDto {
    private String customerName;
    private String contactLastName;
}
